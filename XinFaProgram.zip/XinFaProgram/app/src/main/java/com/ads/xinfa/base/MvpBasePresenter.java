package com.ads.xinfa.base;

/**
 * Created by Ly on 2018/4/10.
 */

public interface MvpBasePresenter{

}
