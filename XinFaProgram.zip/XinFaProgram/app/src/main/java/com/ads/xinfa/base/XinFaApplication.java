package com.ads.xinfa.base;

import android.app.Application;

public class XinFaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        try {



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
