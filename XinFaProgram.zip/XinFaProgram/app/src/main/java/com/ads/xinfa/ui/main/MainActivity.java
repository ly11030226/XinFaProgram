package com.ads.xinfa.ui.main;

import android.content.Context;
import android.os.Bundle;

import com.ads.xinfa.R;
import com.ads.xinfa.base.BaseActivity;

import butterknife.ButterKnife;

public class MainActivity extends BaseActivity implements MainContract.MainView {

    private MainContract.MainPresenter mMainPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        try {
            mMainPresenter = new MainPresenterImpl();
            mMainPresenter.doUDPConnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void showDialog() {

    }

    @Override
    public void hideDialog() {

    }

    @Override
    public void setPresenter(MainContract.MainPresenter presenter) {
        this.mMainPresenter = presenter;
    }

    @Override
    public void showTip(String msg) {

    }

    @Override
    public void showError(String error) {

    }

    @Override
    public boolean isActive() {
        return isActive;
    }

    @Override
    public Context getContext() {
        return this;
    }
}
