package com.ads.xinfa.ui.main;

import com.ads.xinfa.base.MvpBasePresenter;
import com.ads.xinfa.base.MvpBaseView;

public class MainContract {

    public interface MainView extends MvpBaseView<MainPresenter>{
        void showDialog();
        void hideDialog();
    }
    public interface MainPresenter extends MvpBasePresenter{
        //开启UDP连接
        void doUDPConnect();
        //发送心跳包
        void sendHeartBeat();
        //下载文件
        void downloadFile();
    }
}
