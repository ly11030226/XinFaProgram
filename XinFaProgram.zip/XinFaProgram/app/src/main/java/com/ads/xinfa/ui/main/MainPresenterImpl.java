package com.ads.xinfa.ui.main;

import android.content.Context;

public class MainPresenterImpl implements MainContract.MainPresenter{

    private MainContract.MainView mMainView;
    private Context mContext;


    @Override
    public void doUDPConnect() {

    }

    @Override
    public void sendHeartBeat() {

    }

    @Override
    public void downloadFile() {

    }
}
